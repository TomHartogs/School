#ifndef _ACTION_ENUM_H
#define _ACTION_ENUM_H

//Enumerator with actions
enum RP6_ACTION_ENUM
{
	GET_HEIGHT = '1',
	SET_HEIGHT,
	RP6_IN_CHARGE,
	PC_IN_CHARGE
};

#endif
