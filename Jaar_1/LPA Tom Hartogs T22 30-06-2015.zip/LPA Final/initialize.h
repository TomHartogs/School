#ifndef _INITIALIZE_H
#define _INITIALIZE_H

#include "RP6ControlLib.h"

void Initialize( void );

#endif
